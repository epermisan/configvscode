function saymyname() {
  console.log('hello this is Ernest');
}

function writeCountdown(num) {
  console.log(num);
}

function countdown() {
  let comptar = 10; // rename to count

  waitOneSecAndCount = function () {
    if (comptar >= 0) {
      writeCountdown(comptar);
      comptar--;
      setTimeout(() => {
        waitOneSecAndCount();
      }, 1000);
    }
  };

  waitOneSecAndCount()
}

saymyname();
countdown();
