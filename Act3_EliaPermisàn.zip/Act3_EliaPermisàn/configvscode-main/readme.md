# Tasca de Modificació del Codi HTML i JavaScript

En aquesta tasca, es van realitzar les següents modificacions al codi HTML i JavaScript:

## Canvis Realitzats

1. **Canvi a l'arxiu HTML (index.html):**
    - He actualitzat el títol de la pàgina a “Elia Permisàn”.
    - He corregit un error a l'etiqueta `<body>` en canviar `style="margin: 40px;"` a `a="margin: 40px;"`.
    - He afegit una referència al fitxer JavaScript "Elia.js" utilitzant l'etiqueta script.
2. **Creació del fitxer JavaScript (Elia.js):**
    - He creat un fitxer JavaScript anomenat "Elia.js".
    - He afegit una funció anomenada `diAdeu` que mostra "Adéu" a la consola després de 10 segons.
    - He trucat a la funció `diAdeu` per iniciar el compte regressiu quan es carrega la pàgina HTML.

## Dificultats i Reptes

- No ha hagut dificultats importants en aquesta tasca, ja que les modificacions venien amb instruccions.

